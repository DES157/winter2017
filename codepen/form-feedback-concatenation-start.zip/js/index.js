window.onload = function() {
  //check that js is working
  console.log("reading js");

  //capture the submit event
  document.f.onsubmit = process;

  //define process function
  function process() {

    //store user name in a variable
    var userName = document.f.userName.value;

    //store song in a variable called color

    //use the console.log to concatenate a message

    //add a background color change if the user chooses blue as a favorite color

    //prevent page from reloading
    return false;
  }
}