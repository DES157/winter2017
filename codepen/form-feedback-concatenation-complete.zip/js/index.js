window.onload = function() {
  //check that js is working
  console.log("reading js");

  //capture the submit event
  document.f.onsubmit = processForm;

  //capture the reset event
  document.f.onreset = resetPage;

  //define process function
  function processForm() {

    //store user name in a variable
    var userName = document.f.userName.value;
    //store user color in a variable
    var userColor = document.f.color.value;

    //error detection
    if (userName == "" || userColor == "") {
      alert("fill out the form!");

    } else {

      //capture the msg element to change it's text and html
      var myMsg = document.getElementById("myMsg");

      myMsg.innerHTML = "The user's name is <em> " + userName + "</em>. The user's favorite color is <em>" + userColor + "</em>.";
      myMsg.className = "show";
    }

    //prevent page from reloading
    return false;
  }

  //if user chooses "reset"
  function resetPage() {
    //remove any text from myMsg
    myMsg.innerHTML = "";
    //change the class name
    myMsg.className = "hide";
    //reset the userName field
    userName.value = "";
    //reset the userColor field
    userColor.value = "";

    return false;
  }
}